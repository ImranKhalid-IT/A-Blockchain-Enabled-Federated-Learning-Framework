# BC-SHIELD — Pre-Publication Protected Artifact

This archive contains a **pre-publication research software artifact** associated with the BC-SHIELD manuscript.

The implementation payload is intentionally encrypted and is **not distributed as open source at this stage**. The repository is being preserved for version tracking, authorship, and controlled collaboration while the manuscript remains under review / unpublished.

## Important

- The core source code, experiment configurations, blockchain implementation, and reproducibility scripts are stored in an encrypted payload.
- The unlock credential is not included in this repository or archive.
- Possession of this archive does not grant permission to access, reproduce, redistribute, or publish the protected implementation.
- A public reproducibility release can be prepared after manuscript acceptance/publication.

## For collaborators

Access should be obtained directly from the project owner/corresponding research team through a private channel.

## Security note

This protection is designed to prevent casual copying and immediate execution of unpublished research code. It is not a substitute for keeping the GitHub repository **Private** before publication.

© BC-SHIELD research team. Pre-publication research artifact.
