# OWNER NOTES — DO NOT PUBLISH THE OWNER KEY

The protected GitHub ZIP does not contain the unlock key.

## Recommended use

Keep the GitHub repository **Private** until the paper is accepted/published.

Install the one bootstrap dependency:

```bash
pip install cryptography
```

Then either set the key temporarily:

```bash
export BCSHIELD_OWNER_KEY='YOUR_PRIVATE_KEY'
```

In Google Colab:

```python
import os
os.environ["BCSHIELD_OWNER_KEY"] = "YOUR_PRIVATE_KEY"
```

List encrypted project files:

```bash
python owner_bootstrap.py list
```

Run the protected training script without permanently extracting source:

```bash
python owner_bootstrap.py run scripts/train_bcshield.py -- --config configs/ciciot2023.yaml --seed 42
```

Restore the complete source locally when needed:

```bash
python owner_bootstrap.py unpack --destination ./BC_SHIELD_OWNER_SOURCE
```

Never upload the separate owner-key file to GitHub.
