#!/usr/bin/env python3
"""
BC-SHIELD pre-publication owner bootstrap.

The research payload is AES-256-GCM encrypted and split across multiple files.
The unlock key is deliberately NOT stored in this archive.

Requires:
    pip install cryptography

Owner examples:
    python owner_bootstrap.py list
    python owner_bootstrap.py run scripts/train_bcshield.py -- --config configs/ciciot2023.yaml --seed 42
    python owner_bootstrap.py unpack --destination ./BC_SHIELD_OWNER_SOURCE

The key is read from:
    1) --key-file PATH
    2) BCSHIELD_OWNER_KEY environment variable
    3) secure interactive prompt
"""

from __future__ import annotations
import argparse
import base64
import getpass
import hashlib
import os
from pathlib import Path
import subprocess
import sys
import tarfile
import tempfile

ITERATIONS = 600000
SALT = base64.b64decode("5TaE7qyF6pkRFeX9QZkSHg==")
NONCE = base64.b64decode("i+XP783RlzAspqC+")
AAD = b"BCSHIELD_PREPUBLICATION_V1"
EXPECTED_CIPHER_SHA256 = "015a5638de6024a5d8d8f10396f03db0c81082b0ff8901c792c20d41079d1d37"
EXPECTED_PLAIN_SHA256 = "23eb16969f9bc491fe9b20ea8c8133c3c3d5b002a60a5c91c0e4613cd8f5cc3c"
CHUNKS = ['953853c18dcdcf40.bin', 'e1879b440492461e.bin', 'c8e291a800ed4040.bin', '76c71648a74d3f8c.bin', '466cb71ecb29c65f.bin', '55ddb59bbfc6f619.bin', '9798827abc470db3.bin']


def _load_crypto():
    try:
        from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
        from cryptography.hazmat.primitives import hashes
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        return PBKDF2HMAC, hashes, AESGCM
    except Exception:
        print(
            "Missing dependency: cryptography\n"
            "Install it with: pip install cryptography",
            file=sys.stderr,
        )
        raise SystemExit(2)


def _read_owner_key(path: str | None) -> str:
    if path:
        value = Path(path).read_text(encoding="utf-8").strip()
        if value:
            return value
    value = os.environ.get("BCSHIELD_OWNER_KEY", "").strip()
    if value:
        return value
    return getpass.getpass("BC-SHIELD owner key: ").strip()


def _ciphertext() -> bytes:
    root = Path(__file__).resolve().parent / "assets" / ".cache"
    parts = []
    for name in CHUNKS:
        p = root / name
        if not p.exists():
            raise RuntimeError(f"Protected payload component missing: {name}")
        parts.append(p.read_bytes())
    data = b"".join(parts)
    digest = hashlib.sha256(data).hexdigest()
    if digest != EXPECTED_CIPHER_SHA256:
        raise RuntimeError("Encrypted payload integrity check failed.")
    return data


def _decrypt(passphrase: str) -> bytes:
    PBKDF2HMAC, hashes, AESGCM = _load_crypto()
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=SALT,
        iterations=ITERATIONS,
    )
    key = kdf.derive(passphrase.encode("utf-8"))
    try:
        plain = AESGCM(key).decrypt(NONCE, _ciphertext(), AAD)
    except Exception:
        raise RuntimeError("Unlock failed: incorrect owner key or altered payload.")
    if hashlib.sha256(plain).hexdigest() != EXPECTED_PLAIN_SHA256:
        raise RuntimeError("Decrypted payload integrity check failed.")
    return plain


def _safe_extract(tar_path: Path, destination: Path) -> None:
    destination = destination.resolve()
    with tarfile.open(tar_path, "r:gz") as tf:
        for member in tf.getmembers():
            target = (destination / member.name).resolve()
            if destination != target and destination not in target.parents:
                raise RuntimeError("Unsafe path detected in protected payload.")
        try:
            tf.extractall(destination, filter="data")
        except TypeError:  # Python < 3.12
            tf.extractall(destination)


def _materialize(passphrase: str, destination: Path) -> None:
    destination.mkdir(parents=True, exist_ok=True)
    data = _decrypt(passphrase)
    with tempfile.NamedTemporaryFile(suffix=".tar.gz", delete=False) as fh:
        fh.write(data)
        tmp_tar = Path(fh.name)
    try:
        _safe_extract(tmp_tar, destination)
    finally:
        try:
            tmp_tar.unlink()
        except OSError:
            pass


def cmd_list(args) -> int:
    key = _read_owner_key(args.key_file)
    with tempfile.TemporaryDirectory(prefix=".bcs_owner_") as td:
        root = Path(td)
        _materialize(key, root)
        for p in sorted(root.rglob("*")):
            if p.is_file():
                print(p.relative_to(root))
    return 0


def cmd_unpack(args) -> int:
    key = _read_owner_key(args.key_file)
    dest = Path(args.destination).expanduser().resolve()
    if dest.exists() and any(dest.iterdir()) and not args.force:
        print("Destination is not empty. Use --force if intentional.", file=sys.stderr)
        return 3
    dest.mkdir(parents=True, exist_ok=True)
    _materialize(key, dest)
    print(f"Owner source restored to: {dest}")
    return 0


def cmd_run(args) -> int:
    key = _read_owner_key(args.key_file)
    script_rel = Path(args.script)
    if script_rel.is_absolute() or ".." in script_rel.parts:
        print("Script must be a safe path relative to the protected project.", file=sys.stderr)
        return 4

    with tempfile.TemporaryDirectory(prefix=".bcs_runtime_") as td:
        root = Path(td)
        _materialize(key, root)
        script = root / script_rel
        if not script.exists():
            print(f"Protected script not found: {script_rel}", file=sys.stderr)
            return 5

        env = os.environ.copy()
        src_dir = root / "src"
        env["PYTHONPATH"] = str(src_dir) + os.pathsep + env.get("PYTHONPATH", "")

        extra = list(args.script_args)
        if extra and extra[0] == "--":
            extra = extra[1:]

        command = [sys.executable, str(script), *extra]
        print("Launching protected BC-SHIELD runtime...")
        result = subprocess.run(command, cwd=root, env=env)
        return int(result.returncode)


def main() -> int:
    parser = argparse.ArgumentParser(
        description="BC-SHIELD pre-publication protected owner bootstrap"
    )
    parser.add_argument("--key-file", help="Read owner key from a private local file.")
    sub = parser.add_subparsers(dest="command", required=True)

    p_list = sub.add_parser("list", help="List protected project files after unlocking.")
    p_list.set_defaults(func=cmd_list)

    p_unpack = sub.add_parser("unpack", help="Restore the protected source for the owner.")
    p_unpack.add_argument("--destination", required=True)
    p_unpack.add_argument("--force", action="store_true")
    p_unpack.set_defaults(func=cmd_unpack)

    p_run = sub.add_parser("run", help="Run a protected Python script without permanent extraction.")
    p_run.add_argument("script", help="Example: scripts/train_bcshield.py")
    p_run.add_argument("script_args", nargs=argparse.REMAINDER)
    p_run.set_defaults(func=cmd_run)

    args = parser.parse_args()
    try:
        return int(args.func(args))
    except KeyboardInterrupt:
        return 130
    except Exception as exc:
        print(f"BC-SHIELD protected runtime error: {exc}", file=sys.stderr)
        return 10


if __name__ == "__main__":
    raise SystemExit(main())
